<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        if (!Schema::hasTable('admin_users')) {
        Schema::create('admin_users', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->string('email')->unique();
            $table->string('password');
            $table->string('nom');
            $table->timestamps();
        });
        }
    }
    public function down(): void { Schema::dropIfExists('admin_users'); }
};
