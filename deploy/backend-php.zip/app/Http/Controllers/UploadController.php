<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class UploadController extends Controller {
    public function store(Request $request) {
        $request->validate(['file' => 'required|file|max:204800|mimes:jpeg,jpg,png,gif,webp,svg,mp4,webm,mov']);
        $path = $request->file('file')->store('uploads', 'public');
        return response()->json(['url' => '/storage/' . $path, 'filename' => basename($path)]);
    }

    public function destroy($filename) {
        $path = 'uploads/' . $filename;
        if (!Storage::disk('public')->exists($path))
            return response()->json(['error' => 'Fichier non trouvé'], 404);
        Storage::disk('public')->delete($path);
        return response()->json(['message' => 'Fichier supprimé']);
    }
}
